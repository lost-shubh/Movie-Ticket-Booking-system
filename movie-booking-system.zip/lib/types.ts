export interface User {
  id: string
  name: string
  email: string
  created_at: string
}

export interface Movie {
  id: string
  title: string
  description: string
  duration: number
  genre: string
  rating: number
  release_date: string
  poster_url: string
  created_at: string
}

export interface Theater {
  id: string
  name: string
  location: string
  total_seats: number
  created_at: string
}

export interface Showtime {
  id: string
  movie_id: string
  theater_id: string
  show_date: string
  show_time: string
  price: number
  movie_title?: string
  theater_name?: string
  created_at: string
}

export interface Seat {
  id: string
  theater_id: string
  row_number: string
  seat_number: number
  is_booked: boolean
  showtime_id?: string
}

export interface Booking {
  id: string
  user_id: string
  showtime_id: string
  seat_ids: string[]
  total_amount: number
  booking_date: string
  status: "confirmed" | "cancelled"
  movie_title?: string
  theater_name?: string
  show_date?: string
  show_time?: string
}
