import type { Movie, Showtime } from "./types"

// Mock data for demonstration
const mockMovies: Movie[] = [
  {
    id: "1",
    title: "The Dark Knight",
    description:
      "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.",
    duration: 152,
    genre: "Action, Crime, Drama",
    rating: 9.0,
    release_date: "2008-07-18",
    poster_url: "/placeholder.svg?height=600&width=400",
    created_at: "2024-01-01T00:00:00Z",
  },
  {
    id: "2",
    title: "Inception",
    description:
      "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.",
    duration: 148,
    genre: "Action, Sci-Fi, Thriller",
    rating: 8.8,
    release_date: "2010-07-16",
    poster_url: "/placeholder.svg?height=600&width=400",
    created_at: "2024-01-01T00:00:00Z",
  },
  {
    id: "3",
    title: "Interstellar",
    description: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.",
    duration: 169,
    genre: "Adventure, Drama, Sci-Fi",
    rating: 8.6,
    release_date: "2014-11-07",
    poster_url: "/placeholder.svg?height=600&width=400",
    created_at: "2024-01-01T00:00:00Z",
  },
  {
    id: "4",
    title: "The Avengers",
    description:
      "Earth's mightiest heroes must come together and learn to fight as a team if they are going to stop the mischievous Loki and his alien army from enslaving humanity.",
    duration: 143,
    genre: "Action, Adventure, Sci-Fi",
    rating: 8.0,
    release_date: "2012-05-04",
    poster_url: "/placeholder.svg?height=600&width=400",
    created_at: "2024-01-01T00:00:00Z",
  },
]

export async function getMovies(): Promise<Movie[]> {
  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 500))
  return mockMovies
}

export async function getMovieById(id: string): Promise<Movie | null> {
  await new Promise((resolve) => setTimeout(resolve, 300))
  return mockMovies.find((movie) => movie.id === id) || null
}

export async function getShowtimes(movieId: string): Promise<Showtime[]> {
  await new Promise((resolve) => setTimeout(resolve, 300))

  // Mock showtimes
  const today = new Date()
  const tomorrow = new Date(today)
  tomorrow.setDate(tomorrow.getDate() + 1)

  return [
    {
      id: `${movieId}-1`,
      movie_id: movieId,
      theater_id: "1",
      show_date: today.toISOString().split("T")[0],
      show_time: "2024-01-01T14:00:00Z",
      price: 12.99,
      theater_name: "AMC Theater Downtown",
      created_at: "2024-01-01T00:00:00Z",
    },
    {
      id: `${movieId}-2`,
      movie_id: movieId,
      theater_id: "1",
      show_date: today.toISOString().split("T")[0],
      show_time: "2024-01-01T17:30:00Z",
      price: 15.99,
      theater_name: "AMC Theater Downtown",
      created_at: "2024-01-01T00:00:00Z",
    },
    {
      id: `${movieId}-3`,
      movie_id: movieId,
      theater_id: "2",
      show_date: tomorrow.toISOString().split("T")[0],
      show_time: "2024-01-01T19:00:00Z",
      price: 13.99,
      theater_name: "Regal Cinemas Mall",
      created_at: "2024-01-01T00:00:00Z",
    },
  ]
}

export async function getShowtimeById(id: string): Promise<Showtime | null> {
  await new Promise((resolve) => setTimeout(resolve, 300))

  const [movieId] = id.split("-")
  const movie = await getMovieById(movieId)

  if (!movie) return null

  return {
    id,
    movie_id: movieId,
    theater_id: "1",
    show_date: new Date().toISOString().split("T")[0],
    show_time: "2024-01-01T19:00:00Z",
    price: 12.99,
    movie_title: movie.title,
    theater_name: "AMC Theater Downtown",
    created_at: "2024-01-01T00:00:00Z",
  }
}
