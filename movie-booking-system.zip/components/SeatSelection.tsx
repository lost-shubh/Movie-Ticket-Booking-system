"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useRouter } from "next/navigation"
import { useAuth } from "@/components/AuthProvider"
import type { Showtime, Seat } from "@/lib/types"
import { useToast } from "@/hooks/use-toast"

interface SeatSelectionProps {
  showtime: Showtime
}

export default function SeatSelection({ showtime }: SeatSelectionProps) {
  const [seats, setSeats] = useState<Seat[]>([])
  const [selectedSeats, setSelectedSeats] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()
  const router = useRouter()
  const { toast } = useToast()

  useEffect(() => {
    fetchSeats()
  }, [showtime.id])

  const fetchSeats = async () => {
    try {
      const response = await fetch(`/api/seats/${showtime.id}`)
      const data = await response.json()
      setSeats(data)
    } catch (error) {
      console.error("Error fetching seats:", error)
    } finally {
      setLoading(false)
    }
  }

  const toggleSeat = (seatId: string) => {
    setSelectedSeats((prev) => (prev.includes(seatId) ? prev.filter((id) => id !== seatId) : [...prev, seatId]))
  }

  const handleBooking = async () => {
    if (!user) {
      router.push("/login")
      return
    }

    if (selectedSeats.length === 0) {
      toast({
        title: "No seats selected",
        description: "Please select at least one seat to continue.",
        variant: "destructive",
      })
      return
    }

    try {
      const response = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          showtime_id: showtime.id,
          seat_ids: selectedSeats,
          user_id: user.id,
        }),
      })

      if (response.ok) {
        const booking = await response.json()
        router.push(`/booking/confirmation/${booking.id}`)
      } else {
        throw new Error("Booking failed")
      }
    } catch (error) {
      toast({
        title: "Booking failed",
        description: "There was an error processing your booking. Please try again.",
        variant: "destructive",
      })
    }
  }

  const totalPrice = selectedSeats.length * showtime.price

  if (loading) {
    return <div className="text-center">Loading seats...</div>
  }

  // Group seats by row
  const seatRows = seats.reduce(
    (acc, seat) => {
      if (!acc[seat.row_number]) {
        acc[seat.row_number] = []
      }
      acc[seat.row_number].push(seat)
      return acc
    },
    {} as Record<string, Seat[]>,
  )

  return (
    <div className="space-y-8">
      {/* Screen */}
      <div className="screen">
        <div className="text-lg font-semibold">SCREEN</div>
      </div>

      {/* Seat Map */}
      <div className="space-y-4">
        {Object.entries(seatRows)
          .sort(([a], [b]) => a.localeCompare(b))
          .map(([row, rowSeats]) => (
            <div key={row} className="flex items-center justify-center space-x-2">
              <div className="w-8 text-center font-semibold">{row}</div>
              <div className="flex space-x-1">
                {rowSeats
                  .sort((a, b) => a.seat_number - b.seat_number)
                  .map((seat) => (
                    <button
                      key={seat.id}
                      className={`seat ${
                        seat.is_booked ? "booked" : selectedSeats.includes(seat.id) ? "selected" : "available"
                      }`}
                      onClick={() => !seat.is_booked && toggleSeat(seat.id)}
                      disabled={seat.is_booked}
                      title={`${row}${seat.seat_number} - ${seat.is_booked ? "Booked" : "Available"}`}
                    >
                      {seat.seat_number}
                    </button>
                  ))}
              </div>
            </div>
          ))}
      </div>

      {/* Legend */}
      <div className="flex justify-center space-x-6 text-sm">
        <div className="flex items-center space-x-2">
          <div className="seat available w-4 h-4"></div>
          <span>Available</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="seat selected w-4 h-4"></div>
          <span>Selected</span>
        </div>
        <div className="flex items-center space-x-2">
          <div className="seat booked w-4 h-4"></div>
          <span>Booked</span>
        </div>
      </div>

      {/* Booking Summary */}
      {selectedSeats.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Booking Summary</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-between">
                <span>Selected Seats:</span>
                <div className="flex flex-wrap gap-1">
                  {selectedSeats.map((seatId) => {
                    const seat = seats.find((s) => s.id === seatId)
                    return (
                      <Badge key={seatId} variant="secondary">
                        {seat?.row_number}
                        {seat?.seat_number}
                      </Badge>
                    )
                  })}
                </div>
              </div>
              <div className="flex justify-between">
                <span>Number of Tickets:</span>
                <span>{selectedSeats.length}</span>
              </div>
              <div className="flex justify-between">
                <span>Price per Ticket:</span>
                <span>${showtime.price}</span>
              </div>
              <div className="flex justify-between font-semibold text-lg">
                <span>Total Amount:</span>
                <span>${totalPrice}</span>
              </div>
              <Button onClick={handleBooking} className="w-full" size="lg">
                Proceed to Payment
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
