"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { useRouter } from "next/navigation"
import type { Showtime } from "@/lib/types"

interface ShowtimeSelectorProps {
  movieId: string
  showtimes: Showtime[]
}

export default function ShowtimeSelector({ movieId, showtimes }: ShowtimeSelectorProps) {
  const [selectedShowtime, setSelectedShowtime] = useState<string | null>(null)
  const router = useRouter()

  const groupedShowtimes = showtimes.reduce(
    (acc, showtime) => {
      const date = new Date(showtime.show_date).toDateString()
      if (!acc[date]) {
        acc[date] = []
      }
      acc[date].push(showtime)
      return acc
    },
    {} as Record<string, Showtime[]>,
  )

  const handleBooking = () => {
    if (selectedShowtime) {
      router.push(`/booking/${selectedShowtime}`)
    }
  }

  return (
    <div className="space-y-6">
      {Object.entries(groupedShowtimes).map(([date, times]) => (
        <div key={date}>
          <h4 className="font-semibold mb-3">{date}</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {times.map((showtime) => (
              <Card
                key={showtime.id}
                className={`cursor-pointer transition-all ${
                  selectedShowtime === showtime.id ? "ring-2 ring-blue-500 bg-blue-50" : "hover:shadow-md"
                }`}
                onClick={() => setSelectedShowtime(showtime.id)}
              >
                <CardContent className="p-3 text-center">
                  <div className="font-semibold">
                    {new Date(showtime.show_time).toLocaleTimeString([], {
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </div>
                  <div className="text-sm text-gray-600">{showtime.theater_name}</div>
                  <Badge variant="outline" className="mt-1">
                    ${showtime.price}
                  </Badge>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      ))}

      {selectedShowtime && (
        <div className="flex justify-center pt-4">
          <Button onClick={handleBooking} size="lg">
            Select Seats
          </Button>
        </div>
      )}
    </div>
  )
}
