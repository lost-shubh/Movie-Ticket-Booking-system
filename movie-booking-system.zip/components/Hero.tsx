import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function Hero() {
  return (
    <section className="bg-gradient-to-r from-blue-600 to-purple-700 text-white py-20">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-5xl md:text-6xl font-bold mb-6">Book Your Movie Tickets</h1>
        <p className="text-xl md:text-2xl mb-8 max-w-2xl mx-auto">
          Experience the latest blockbusters in premium comfort. Book your seats now and enjoy the magic of cinema.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Link href="/movies">
            <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
              Browse Movies
            </Button>
          </Link>
          <Link href="/theaters">
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600">
              Find Theaters
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}
