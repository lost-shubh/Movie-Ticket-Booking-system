"use client"

import Link from "next/link"
import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Menu, X, Film } from "lucide-react"
import { useAuth } from "@/components/AuthProvider"

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false)
  const { user, logout } = useAuth()

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center py-4">
          <Link href="/" className="flex items-center space-x-2">
            <Film className="h-8 w-8 text-blue-600" />
            <span className="text-2xl font-bold text-gray-800">CineBook</span>
          </Link>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-6">
            <Link href="/" className="text-gray-700 hover:text-blue-600 transition-colors">
              Home
            </Link>
            <Link href="/movies" className="text-gray-700 hover:text-blue-600 transition-colors">
              Movies
            </Link>
            <Link href="/theaters" className="text-gray-700 hover:text-blue-600 transition-colors">
              Theaters
            </Link>
            {user ? (
              <div className="flex items-center space-x-4">
                <Link href="/bookings" className="text-gray-700 hover:text-blue-600 transition-colors">
                  My Bookings
                </Link>
                <span className="text-gray-700">Hi, {user.name}</span>
                <Button onClick={logout} variant="outline" size="sm">
                  Logout
                </Button>
              </div>
            ) : (
              <div className="flex items-center space-x-2">
                <Link href="/login">
                  <Button variant="outline" size="sm">
                    Login
                  </Button>
                </Link>
                <Link href="/register">
                  <Button size="sm">Sign Up</Button>
                </Link>
              </div>
            )}
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
            {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="md:hidden py-4 border-t">
            <div className="flex flex-col space-y-4">
              <Link href="/" className="text-gray-700 hover:text-blue-600">
                Home
              </Link>
              <Link href="/movies" className="text-gray-700 hover:text-blue-600">
                Movies
              </Link>
              <Link href="/theaters" className="text-gray-700 hover:text-blue-600">
                Theaters
              </Link>
              {user ? (
                <>
                  <Link href="/bookings" className="text-gray-700 hover:text-blue-600">
                    My Bookings
                  </Link>
                  <Button onClick={logout} variant="outline" size="sm" className="w-fit">
                    Logout
                  </Button>
                </>
              ) : (
                <div className="flex space-x-2">
                  <Link href="/login">
                    <Button variant="outline" size="sm">
                      Login
                    </Button>
                  </Link>
                  <Link href="/register">
                    <Button size="sm">Sign Up</Button>
                  </Link>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  )
}
