-- Insert sample data for movie booking system

-- Insert sample theaters
INSERT INTO theaters (id, name, location, address, city, state, zip_code, phone, total_seats, facilities) VALUES
('550e8400-e29b-41d4-a716-446655440001', 'AMC Theater Downtown', 'Downtown District', '123 Main Street', 'New York', 'NY', '10001', '(555) 123-4567', 200, ARRAY['IMAX', 'Dolby Atmos', '3D']),
('550e8400-e29b-41d4-a716-446655440002', 'Regal Cinemas Mall', 'Shopping Mall Complex', '456 Mall Avenue', 'New York', 'NY', '10002', '(555) 234-5678', 150, ARRAY['Dolby', 'Recliner Seats']),
('550e8400-e29b-41d4-a716-446655440003', 'Cinemark Uptown', 'Uptown Area', '789 Broadway', 'New York', 'NY', '10003', '(555) 345-6789', 180, ARRAY['IMAX', 'XD', 'Luxury Loungers']);

-- Insert sample movies
INSERT INTO movies (id, title, description, duration, genre, rating, release_date, poster_url, director, cast) VALUES
('660e8400-e29b-41d4-a716-446655440001', 'The Dark Knight', 'When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice.', 152, 'Action, Crime, Drama', 9.0, '2008-07-18', '/placeholder.svg?height=600&width=400', 'Christopher Nolan', 'Christian Bale, Heath Ledger, Aaron Eckhart'),
('660e8400-e29b-41d4-a716-446655440002', 'Inception', 'A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O.', 148, 'Action, Sci-Fi, Thriller', 8.8, '2010-07-16', '/placeholder.svg?height=600&width=400', 'Christopher Nolan', 'Leonardo DiCaprio, Marion Cotillard, Tom Hardy'),
('660e8400-e29b-41d4-a716-446655440003', 'Interstellar', 'A team of explorers travel through a wormhole in space in an attempt to ensure humanity''s survival.', 169, 'Adventure, Drama, Sci-Fi', 8.6, '2014-11-07', '/placeholder.svg?height=600&width=400', 'Christopher Nolan', 'Matthew McConaughey, Anne Hathaway, Jessica Chastain'),
('660e8400-e29b-41d4-a716-446655440004', 'The Avengers', 'Earth''s mightiest heroes must come together and learn to  'The Avengers', 'Earth''s mightiest heroes must come together and learn to fight as a team if they are going to stop the mischievous Loki and his alien army from enslaving humanity.', 143, 'Action, Adventure, Sci-Fi', 8.0, '2012-05-04', '/placeholder.svg?height=600&width=400', 'Joss Whedon', 'Robert Downey Jr., Chris Evans, Mark Ruffalo'),
('660e8400-e29b-41d4-a716-446655440005', 'Spider-Man: No Way Home', 'With Spider-Man''s identity now revealed, Peter asks Doctor Strange for help. When a spell goes wrong, dangerous foes from other worlds start to appear.', 148, 'Action, Adventure, Sci-Fi', 8.4, '2021-12-17', '/placeholder.svg?height=600&width=400', 'Jon Watts', 'Tom Holland, Zendaya, Benedict Cumberbatch'),
('660e8400-e29b-41d4-a716-446655440006', 'Top Gun: Maverick', 'After thirty years, Maverick is still pushing the envelope as a top naval aviator, but must confront ghosts of his past when he leads TOP GUN''s elite graduates on a mission that demands the ultimate sacrifice.', 130, 'Action, Drama', 8.3, '2022-05-27', '/placeholder.svg?height=600&width=400', 'Joseph Kosinski', 'Tom Cruise, Miles Teller, Jennifer Connelly');

-- Insert sample users
INSERT INTO users (id, name, email, password_hash, phone) VALUES
('770e8400-e29b-41d4-a716-446655440001', 'John Doe', 'john.doe@example.com', '$2b$10$hash1', '(555) 111-2222'),
('770e8400-e29b-41d4-a716-446655440002', 'Jane Smith', 'jane.smith@example.com', '$2b$10$hash2', '(555) 333-4444'),
('770e8400-e29b-41d4-a716-446655440003', 'Mike Johnson', 'mike.johnson@example.com', '$2b$10$hash3', '(555) 555-6666');

-- Insert seats for theaters
-- Theater 1 (AMC Downtown) - 200 seats
INSERT INTO seats (theater_id, row_number, seat_number, seat_type)
SELECT 
    '550e8400-e29b-41d4-a716-446655440001',
    chr(64 + row_num),
    seat_num,
    CASE 
        WHEN row_num <= 2 THEN 'premium'
        WHEN row_num >= 8 THEN 'vip'
        ELSE 'regular'
    END
FROM 
    generate_series(1, 10) AS row_num,
    generate_series(1, 20) AS seat_num;

-- Theater 2 (Regal Mall) - 150 seats
INSERT INTO seats (theater_id, row_number, seat_number, seat_type)
SELECT 
    '550e8400-e29b-41d4-a716-446655440002',
    chr(64 + row_num),
    seat_num,
    CASE 
        WHEN row_num <= 2 THEN 'premium'
        ELSE 'regular'
    END
FROM 
    generate_series(1, 10) AS row_num,
    generate_series(1, 15) AS seat_num;

-- Theater 3 (Cinemark Uptown) - 180 seats
INSERT INTO seats (theater_id, row_number, seat_number, seat_type)
SELECT 
    '550e8400-e29b-41d4-a716-446655440003',
    chr(64 + row_num),
    seat_num,
    CASE 
        WHEN row_num <= 3 THEN 'premium'
        WHEN row_num >= 7 THEN 'vip'
        ELSE 'regular'
    END
FROM 
    generate_series(1, 10) AS row_num,
    generate_series(1, 18) AS seat_num;

-- Insert sample showtimes for the next 7 days
INSERT INTO showtimes (movie_id, theater_id, show_date, show_time, price, available_seats) VALUES
-- The Dark Knight showtimes
('660e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', CURRENT_DATE, '14:00:00', 12.99, 200),
('660e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', CURRENT_DATE, '17:30:00', 15.99, 200),
('660e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440001', CURRENT_DATE, '21:00:00', 15.99, 200),
('660e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440002', CURRENT_DATE + 1, '15:00:00', 13.99, 150),
('660e8400-e29b-41d4-a716-446655440001', '550e8400-e29b-41d4-a716-446655440002', CURRENT_DATE + 1, '19:00:00', 16.99, 150),

-- Inception showtimes
('660e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440002', CURRENT_DATE, '16:00:00', 14.99, 150),
('660e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440002', CURRENT_DATE, '20:00:00', 17.99, 150),
('660e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440003', CURRENT_DATE + 1, '14:30:00', 15.99, 180),
('660e8400-e29b-41d4-a716-446655440002', '550e8400-e29b-41d4-a716-446655440003', CURRENT_DATE + 1, '18:30:00', 18.99, 180),

-- Interstellar showtimes
('660e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440003', CURRENT_DATE, '13:00:00', 16.99, 180),
('660e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440003', CURRENT_DATE, '17:00:00', 19.99, 180),
('660e8400-e29b-41d4-a716-446655440003', '550e8400-e29b-41d4-a716-446655440001', CURRENT_DATE + 2, '15:30:00', 17.99, 200),

-- The Avengers showtimes
('660e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440001', CURRENT_DATE, '12:00:00', 11.99, 200),
('660e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440001', CURRENT_DATE, '15:30:00', 14.99, 200),
('660e8400-e29b-41d4-a716-446655440004', '550e8400-e29b-41d4-a716-446655440002', CURRENT_DATE + 1, '13:30:00', 12.99, 150);

-- Insert sample coupons
INSERT INTO coupons (code, description, discount_type, discount_value, min_amount, valid_from, valid_until, usage_limit) VALUES
('WELCOME10', '10% off for new users', 'percentage', 10.00, 20.00, CURRENT_DATE - INTERVAL '30 days', CURRENT_DATE + INTERVAL '30 days', 100),
('MOVIE20', '$20 off on bookings above $50', 'fixed', 20.00, 50.00, CURRENT_DATE - INTERVAL '7 days', CURRENT_DATE + INTERVAL '60 days', 50),
('WEEKEND15', '15% off weekend shows', 'percentage', 15.00, 25.00, CURRENT_DATE, CURRENT_DATE + INTERVAL '90 days', 200);
