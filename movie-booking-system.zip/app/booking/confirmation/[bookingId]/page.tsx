import { notFound } from "next/navigation"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { CheckCircle, Download, Mail } from "lucide-react"
import Link from "next/link"

interface BookingConfirmationProps {
  params: {
    bookingId: string
  }
}

// Mock function to get booking details
async function getBookingById(id: string) {
  // In real app, fetch from database
  return {
    id,
    user_id: "1",
    showtime_id: "1-1",
    seat_ids: ["A1", "A2"],
    total_amount: 25.98,
    booking_date: new Date().toISOString(),
    status: "confirmed" as const,
    movie_title: "The Dark Knight",
    theater_name: "AMC Theater Downtown",
    show_date: new Date().toISOString().split("T")[0],
    show_time: "2024-01-01T19:00:00Z",
  }
}

export default async function BookingConfirmationPage({ params }: BookingConfirmationProps) {
  const booking = await getBookingById(params.bookingId)

  if (!booking) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-2xl mx-auto">
        <div className="text-center mb-8">
          <CheckCircle className="w-16 h-16 text-green-500 mx-auto mb-4" />
          <h1 className="text-3xl font-bold text-green-600 mb-2">Booking Confirmed!</h1>
          <p className="text-gray-600">Your tickets have been successfully booked.</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              Booking Details
              <Badge variant="secondary">#{booking.id}</Badge>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <h3 className="font-semibold text-gray-700">Movie</h3>
                <p className="text-lg">{booking.movie_title}</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-700">Theater</h3>
                <p>{booking.theater_name}</p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-700">Date & Time</h3>
                <p>{new Date(booking.show_date).toDateString()}</p>
                <p>
                  {new Date(booking.show_time).toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
              </div>
              <div>
                <h3 className="font-semibold text-gray-700">Seats</h3>
                <div className="flex flex-wrap gap-1">
                  {booking.seat_ids.map((seatId) => (
                    <Badge key={seatId} variant="outline">
                      {seatId}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>

            <div className="border-t pt-4">
              <div className="flex justify-between items-center text-lg font-semibold">
                <span>Total Amount Paid:</span>
                <span>${booking.total_amount}</span>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button className="flex-1">
                <Download className="w-4 h-4 mr-2" />
                Download Ticket
              </Button>
              <Button variant="outline" className="flex-1">
                <Mail className="w-4 h-4 mr-2" />
                Email Ticket
              </Button>
            </div>

            <div className="text-center">
              <Link href="/bookings">
                <Button variant="link">View All Bookings</Button>
              </Link>
            </div>
          </CardContent>
        </Card>

        <div className="mt-8 p-4 bg-blue-50 rounded-lg">
          <h3 className="font-semibold text-blue-800 mb-2">Important Information:</h3>
          <ul className="text-sm text-blue-700 space-y-1">
            <li>• Please arrive at least 15 minutes before showtime</li>
            <li>• Carry a valid ID for verification</li>
            <li>• Outside food and beverages are not allowed</li>
            <li>• Tickets are non-refundable but can be rescheduled</li>
          </ul>
        </div>
      </div>
    </div>
  )
}
