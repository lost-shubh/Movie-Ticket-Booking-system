import { notFound } from "next/navigation"
import { getShowtimeById } from "@/lib/api"
import SeatSelection from "@/components/SeatSelection"

interface BookingPageProps {
  params: {
    showtimeId: string
  }
}

export default async function BookingPage({ params }: BookingPageProps) {
  const showtime = await getShowtimeById(params.showtimeId)

  if (!showtime) {
    notFound()
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold mb-2">{showtime.movie_title}</h1>
          <p className="text-gray-600">
            {showtime.theater_name} • {new Date(showtime.show_date).toDateString()} •{" "}
            {new Date(showtime.show_time).toLocaleTimeString([], {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </p>
        </div>

        <SeatSelection showtime={showtime} />
      </div>
    </div>
  )
}
