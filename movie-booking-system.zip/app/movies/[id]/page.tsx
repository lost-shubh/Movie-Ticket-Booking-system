import { notFound } from "next/navigation"
import Image from "next/image"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Star, Clock, Calendar } from "lucide-react"
import { getMovieById, getShowtimes } from "@/lib/api"
import ShowtimeSelector from "@/components/ShowtimeSelector"

interface MoviePageProps {
  params: {
    id: string
  }
}

export default async function MoviePage({ params }: MoviePageProps) {
  const movie = await getMovieById(params.id)

  if (!movie) {
    notFound()
  }

  const showtimes = await getShowtimes(params.id)

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-1">
          <Image
            src={movie.poster_url || `/placeholder.svg?height=600&width=400`}
            alt={movie.title}
            width={400}
            height={600}
            className="w-full rounded-lg shadow-lg"
          />
        </div>

        <div className="lg:col-span-2">
          <h1 className="text-4xl font-bold mb-4">{movie.title}</h1>

          <div className="flex items-center space-x-4 mb-6">
            <Badge className="bg-yellow-500 text-black">
              <Star className="w-4 h-4 mr-1" />
              {movie.rating}
            </Badge>
            <div className="flex items-center text-gray-600">
              <Clock className="w-4 h-4 mr-1" />
              {movie.duration} min
            </div>
            <div className="flex items-center text-gray-600">
              <Calendar className="w-4 h-4 mr-1" />
              {new Date(movie.release_date).getFullYear()}
            </div>
          </div>

          <div className="flex flex-wrap gap-2 mb-6">
            {movie.genre.split(",").map((g, index) => (
              <Badge key={index} variant="secondary">
                {g.trim()}
              </Badge>
            ))}
          </div>

          <p className="text-gray-700 mb-8 leading-relaxed">{movie.description}</p>

          <Card>
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold mb-4">Select Showtime</h3>
              <ShowtimeSelector movieId={params.id} showtimes={showtimes} />
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
