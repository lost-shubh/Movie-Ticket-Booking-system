"use client"

import { useEffect, useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, MapPin, Ticket } from "lucide-react"
import { useAuth } from "@/components/AuthProvider"
import type { Booking } from "@/lib/types"

export default function BookingsPage() {
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(true)
  const { user } = useAuth()

  useEffect(() => {
    if (user) {
      fetchBookings()
    }
  }, [user])

  const fetchBookings = async () => {
    try {
      // Mock bookings data
      const mockBookings: Booking[] = [
        {
          id: "1",
          user_id: user?.id || "1",
          showtime_id: "1-1",
          seat_ids: ["A1", "A2"],
          total_amount: 25.98,
          booking_date: new Date().toISOString(),
          status: "confirmed",
          movie_title: "The Dark Knight",
          theater_name: "AMC Theater Downtown",
          show_date: new Date().toISOString().split("T")[0],
          show_time: "2024-01-01T19:00:00Z",
        },
        {
          id: "2",
          user_id: user?.id || "1",
          showtime_id: "2-1",
          seat_ids: ["B5", "B6", "B7"],
          total_amount: 44.97,
          booking_date: new Date(Date.now() - 86400000).toISOString(),
          status: "confirmed",
          movie_title: "Inception",
          theater_name: "Regal Cinemas Mall",
          show_date: new Date(Date.now() + 86400000).toISOString().split("T")[0],
          show_time: "2024-01-01T20:00:00Z",
        },
      ]
      setBookings(mockBookings)
    } catch (error) {
      console.error("Error fetching bookings:", error)
    } finally {
      setLoading(false)
    }
  }

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-16 text-center">
        <h1 className="text-2xl font-bold mb-4">Please Login</h1>
        <p className="text-gray-600 mb-8">You need to be logged in to view your bookings.</p>
        <Button onClick={() => (window.location.href = "/login")}>Login</Button>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="container mx-auto px-4 py-8">
        <div className="text-center">Loading your bookings...</div>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">My Bookings</h1>

      {bookings.length === 0 ? (
        <div className="text-center py-16">
          <Ticket className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-600 mb-2">No bookings yet</h2>
          <p className="text-gray-500 mb-8">Start by booking your favorite movies!</p>
          <Button onClick={() => (window.location.href = "/movies")}>Browse Movies</Button>
        </div>
      ) : (
        <div className="space-y-6">
          {bookings.map((booking) => (
            <Card key={booking.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <CardTitle className="text-xl">{booking.movie_title}</CardTitle>
                  <Badge variant={booking.status === "confirmed" ? "default" : "destructive"}>{booking.status}</Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                  <div className="flex items-center space-x-2">
                    <MapPin className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">{booking.theater_name}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">{new Date(booking.show_date || "").toDateString()}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span className="text-sm">
                      {new Date(booking.show_time || "").toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-600">Seats: {booking.seat_ids.join(", ")}</p>
                    <p className="font-semibold">Total: ${booking.total_amount}</p>
                  </div>
                  <div className="space-x-2">
                    <Button variant="outline" size="sm">
                      View Details
                    </Button>
                    <Button variant="outline" size="sm">
                      Download Ticket
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  )
}
