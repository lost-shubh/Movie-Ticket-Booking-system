import { Suspense } from "react"
import MovieGrid from "@/components/MovieGrid"
import Hero from "@/components/Hero"
import { getMovies } from "@/lib/api"

export default async function HomePage() {
  const movies = await getMovies()

  return (
    <main className="min-h-screen">
      <Hero />
      <section className="container mx-auto px-4 py-12">
        <h2 className="text-3xl font-bold text-center mb-8">Now Showing</h2>
        <Suspense fallback={<div className="text-center">Loading movies...</div>}>
          <MovieGrid movies={movies} />
        </Suspense>
      </section>
    </main>
  )
}
