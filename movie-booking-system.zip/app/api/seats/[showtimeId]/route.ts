import { type NextRequest, NextResponse } from "next/server"
import type { Seat } from "@/lib/types"

export async function GET(request: NextRequest, { params }: { params: { showtimeId: string } }) {
  try {
    // Mock seat data - in real app, fetch from database
    const seats: Seat[] = []
    const rows = ["A", "B", "C", "D", "E", "F"]
    const seatsPerRow = 10

    rows.forEach((row) => {
      for (let seatNum = 1; seatNum <= seatsPerRow; seatNum++) {
        seats.push({
          id: `${row}${seatNum}`,
          theater_id: "1",
          row_number: row,
          seat_number: seatNum,
          is_booked: Math.random() < 0.3, // 30% chance of being booked
          showtime_id: params.showtimeId,
        })
      }
    })

    return NextResponse.json(seats)
  } catch (error) {
    return NextResponse.json({ error: "Failed to fetch seats" }, { status: 500 })
  }
}
