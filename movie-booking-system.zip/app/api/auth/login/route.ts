import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    // Mock authentication - in real app, verify against database
    if (email === "user@example.com" && password === "password") {
      const user = {
        id: "1",
        name: "John Doe",
        email: email,
        created_at: new Date().toISOString(),
      }

      return NextResponse.json({ user })
    }

    return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
  } catch (error) {
    return NextResponse.json({ error: "Login failed" }, { status: 500 })
  }
}
