import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { name, email, password } = await request.json()

    // Mock registration - in real app, save to database
    const user = {
      id: Date.now().toString(),
      name,
      email,
      created_at: new Date().toISOString(),
    }

    return NextResponse.json({ user })
  } catch (error) {
    return NextResponse.json({ error: "Registration failed" }, { status: 500 })
  }
}
