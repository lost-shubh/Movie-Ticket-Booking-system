import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { showtime_id, seat_ids, user_id } = await request.json()

    // Mock booking creation - in real app, save to database
    const booking = {
      id: Date.now().toString(),
      user_id,
      showtime_id,
      seat_ids,
      total_amount: seat_ids.length * 12.99,
      booking_date: new Date().toISOString(),
      status: "confirmed" as const,
    }

    return NextResponse.json(booking)
  } catch (error) {
    return NextResponse.json({ error: "Booking failed" }, { status: 500 })
  }
}
